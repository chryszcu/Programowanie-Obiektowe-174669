public class KlienIndywidualny extends Klient{
    public final int PESEL = 22032251;

    public KlienIndywidualny(String imie, String nazwisko) {
        super(imie, nazwisko);
    }
}
