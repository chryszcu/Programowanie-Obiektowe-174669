import java.util.ArrayList;

public class Klient extends Osoba {
    ArrayList<Zamowienie> listaZamowien;

    public Klient(String imie, String nazwisko) {
        super(imie, nazwisko);
        this.listaZamowien = new ArrayList<>();
    }

    public void dodajZamowienie(Zamowienie zamowienie) {
        listaZamowien.add(zamowienie);
    }

    public void wyswietlHistorieZamowien(){
        int i = 1;
        for(Zamowienie zamowienie : listaZamowien){
            System.out.println("Zamowienie: "+i);
            zamowienie.wyswietlZamowienie();
            i++;
            System.out.println();
        }
    }

    public double obliczLacznyKosztZamowien(){
        double koszt = 0;
        for(Zamowienie zamowienie : listaZamowien){
            KoszykZakupowy koszykZakupowy = zamowienie.getKoszykZakupowy();
            koszt += koszykZakupowy.obliczCalkowitaWartosc();
        }
        return koszt;
    }
}
