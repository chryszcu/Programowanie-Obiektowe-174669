abstract class Warzywo{
    public abstract String smak();
    public abstract void umyj();
    public abstract void zjedz();
}
