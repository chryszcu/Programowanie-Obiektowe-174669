public class Osoba {
    private String imie;
    private String nazwisko;

    public Osoba(String nazwisko, String imie) {
        this.nazwisko = nazwisko;
        this.imie = imie;
    }
}
