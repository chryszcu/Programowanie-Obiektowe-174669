import java.util.ArrayList;

public class Zamowienie {
    private KoszykZakupowy koszykZakupowy;
    private String statusZamowienie;

    public Zamowienie(KoszykZakupowy koszykZakupowy, String statusZamowienie) {
        this.statusZamowienie = statusZamowienie;
        this.koszykZakupowy = koszykZakupowy;
    }

    public void ustawStatusZamowienia(String statusZamowienia) {
        this.statusZamowienie = statusZamowienia;
    }

    public KoszykZakupowy getKoszykZakupowy(){
        return koszykZakupowy;
    }

    public void wyswietlZamowienie() {
        koszykZakupowy.wyswietlZawartoscKoszyka();
        System.out.println("Wartosc zamowienia: " +koszykZakupowy.obliczCalkowitaWartosc());
        System.out.println(statusZamowienie);
    }
}
