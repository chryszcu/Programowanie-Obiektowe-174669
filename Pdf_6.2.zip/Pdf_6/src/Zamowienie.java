import java.util.ArrayList;

public class Zamowienie {
    private ArrayList<KoszykZakupowy> koszykZakupowy;
    private String statusZamowienie;

    public Zamowienie() {
        this.statusZamowienie = new String();
        this.koszykZakupowy = new ArrayList<>();
    }

    public void ustawStatusZamowienia(String statusZamowienia) {
        this.statusZamowienie = statusZamowienia;
    }

    public void wyswietlZamowienie(KoszykZakupowy koszykZakupowy) {
        koszykZakupowy.wyswietlProdukt();
        koszykZakupowy.obliczCalkowitaWartosc();
        System.out.println(statusZamowienie);
    }
}
