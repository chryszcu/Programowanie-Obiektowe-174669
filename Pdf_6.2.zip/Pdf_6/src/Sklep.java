import java.util.ArrayList;

public class Sklep {
    ArrayList<Produkt> produkty;

    public Sklep() {
        this.produkty = new ArrayList<>();
    }

    public void dodajProdukt(Produkt produkt){
        produkty.add(produkt);
    }

    public void wyswietlOferty(){
        for(Produkt produkt : produkty){
            produkt.wyswietlInformacje();
            System.out.println();
        }
    }
}
