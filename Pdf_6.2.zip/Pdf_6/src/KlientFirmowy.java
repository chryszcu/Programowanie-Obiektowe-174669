public class KlientFirmowy extends Klient{
    public final String NIP = "023543421";
    public final int REGON = 54134112;

    public KlientFirmowy(String imie, String nazwisko) {
        super(imie, nazwisko);
    }
}
