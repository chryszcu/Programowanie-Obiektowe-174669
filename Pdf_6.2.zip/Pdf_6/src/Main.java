public class Main {


    public static void main(String[] args) {
        Produkt produkt1 = new Produkt("Bułki", 5, 15);
        Produkt produkt2 = new Produkt("Masło", 7, 5);
        Produkt produkt3 = new Produkt("Szynka", 9, 19);
        Produkt produkt4 = new Produkt("Pomidor", 2, 12);
        KoszykZakupowy koszyk = new KoszykZakupowy();
        KoszykZakupowy koszyk2 = new KoszykZakupowy();
        Zamowienie zamowienie = new Zamowienie(koszyk, "Oplacony");
        Zamowienie zamowienie2 = new Zamowienie(koszyk2, "NieOplacony");
        Klient klient = new Klient("Michal", "AAA");
        Sklep sklep = new Sklep();
        sklep.dodajProdukt(produkt1);
        sklep.dodajProdukt(produkt2);
        sklep.dodajProdukt(produkt3);

        koszyk.dodajProdukt(produkt4, 4);
        koszyk.dodajProdukt(produkt3, 3);
        koszyk.dodajProdukt(produkt2, 2);

        koszyk2.dodajProdukt(produkt4, 4);
        koszyk2.dodajProdukt(produkt3, 3);
        koszyk2.dodajProdukt(produkt2, 2);

        klient.dodajZamowienie(zamowienie);
        klient.dodajZamowienie(zamowienie2);
        klient.wyswietlHistorieZamowien();
        System.out.println("Lączny koszt: " +klient.obliczLacznyKosztZamowien());
        sklep.wyswietlOferty();
    }

}