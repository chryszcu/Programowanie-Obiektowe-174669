public class Main {


    public static void main(String[] args) {
        Produkt produkt1 = new Produkt("Bułki", 5, 15);
        Produkt produkt2 = new Produkt("Masło", 7, 5);
        Produkt produkt3 = new Produkt("Szynka", 9, 19);
        Produkt produkt4 = new Produkt("Pomidor", 2, 12);
        KoszykZakupowy koszyk = new KoszykZakupowy();
        Zamowienie zamowienie = new Zamowienie();
        Klient klient = new Klient("Michal", "Debil");
        koszyk.dodajProdukt(produkt4, 4);
        koszyk.dodajProdukt(produkt3, 3);
        koszyk.dodajProdukt(produkt2, 2);
        zamowienie.ustawStatusZamowienia("Oplacony");
        zamowienie.wyswietlZamowienie(koszyk);
        klient.dodajZamowienie(zamowienie);


    }

}