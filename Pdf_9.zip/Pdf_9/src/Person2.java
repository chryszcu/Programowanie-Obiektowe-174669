public record Person2(String firstName, int age) {
    public Person2(String firstName, int age) {
        this.firstName = firstName;
        if (age < 0) {
            this.age = 0;
        }
        else this.age = age;
    }
}
