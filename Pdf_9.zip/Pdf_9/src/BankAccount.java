public record BankAccount(String id_number, double balance) {
    public BankAccount(String id_number) {
        this(id_number, 0.0);
    }
}
