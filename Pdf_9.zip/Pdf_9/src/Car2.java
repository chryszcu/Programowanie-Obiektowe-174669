public class Car2 {
    private String make;
    private String model;
    private Engine engine;

    public Car2(String make, Engine engine, String model) {
        this.make = make;
        this.engine = engine;
        this.model = model;
    }

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public Engine getEngine() {
        return engine;
    }

    public void setEngine(Engine engine) {
        this.engine = engine;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    @Override
    public String toString() {
        return "Car2{" +
                "make='" + make + '\'' +
                ", model='" + model + '\'' +
                ", engine=" + engine +
                '}';
    }

    @Override
    public final boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Car2 car2)) return false;

        return getMake().equals(car2.getMake()) && getModel().equals(car2.getModel()) && getEngine().equals(car2.getEngine());
    }

    @Override
    public int hashCode() {
        int result = getMake().hashCode();
        result = 31 * result + getModel().hashCode();
        result = 31 * result + getEngine().hashCode();
        return result;
    }
}
