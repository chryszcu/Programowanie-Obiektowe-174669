public record BookDTO(String title, String author, int price, int yearOfPublication) {
}




