public class Electronics {
    public void turnOn(){
        System.out.println("Turning on");
    }
}
