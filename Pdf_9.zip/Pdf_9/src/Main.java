public class Main {
    public static void main(String[] args) {
        BookDTO book = new BookDTO("Ksiazka 1", "Adam Mickiewicz", 30, 1900);
        BookDTO book1 = new BookDTO("Ksiazka 2", "Adam Mickiewicz", 35, 1903);
        BookDTO book2 = new BookDTO("Ksiazka 3", "Adam Mickiewicz", 40, 1930);

        Address address = new Address("Rolna", 12, 31254, "Olsztyn");

        Person person = new Person("Jakub", "Nowak", address);

        Car car = new Car("BMW", "M3", 15);

        Person2 person_2 = new Person2("kuba", 21);

        BankAccount account = new BankAccount("4132");

        Book book3 = new Book("Kolorowy", "Jakub");
        book3.addReview(3.2);
        book3.addReview(3.5);
        System.out.println(book3);

        System.out.println(account);
        System.out.println(person_2);
        System.out.println(car);
        System.out.println(car.fuelCost(6, 20));

        System.out.println(person);
        System.out.println("Name: " + person.firstName());
        System.out.println("Adress: " + person.address());

        Electronics electronics = new Electronics();
        Television television = new Television();

        television.turnOn();
        electronics.turnOn();

        ImmutableBook book4 = new ImmutableBook("a", "b", "123");
        System.out.println(book4);
        System.out.println("Autor" + book4.getAuthor());
        System.out.println("Title" + book4.getTitle());
        System.out.println("isb" + book4.getIsbn());
        ImmutableBook book5 = new ImmutableBook("a", "b", "123");

        System.out.println("czy sa rowne" + book4.equals(book5));

        System.out.println(book4.hashCode());
        System.out.println(book5.hashCode());

    }
}