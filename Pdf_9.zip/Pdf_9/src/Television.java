public class Television extends Electronics{
    public void turnOn(){
        System.out.println("Turning on television");
    }
}
