class Pair<T> {
    private T obiekt;
    private T obiekt2;

    public Pair() {

    }

    public T getObiekt() {
        return obiekt;
    }

    public void setObiekt(T obiekt) {
        this.obiekt = obiekt;
    }

    public T getObiekt2() {
        return obiekt2;
    }

    public void setObiekt2(T obiekt2) {
        this.obiekt2 = obiekt2;
    }

    @Override
    public String toString() {
        return "Pair{" +
                "obiekt=" + obiekt +
                ", obiekt2=" + obiekt2 +
                '}';
    }
}

public class TestPair {
    public static void findMinMaxAge(Dog[] dogs, Pair<?super Dog> results) {
        Dog min = dogs[0];
        Dog max = dogs[0];
        for(Dog d : dogs) {
            if(d.getAge() < min.getAge()){
                min = d;
            }
            if(d.getAge() > max.getAge()){
                max = d;
            }
        }
        results.setObiekt(min);
        results.setObiekt2(max);

    }

    public static void main(String[] args) {
        Dog[] dogs = new Dog[3];
        Dog dog1 = new Dog("Czarek", 3);
        Dog dog2 = new Dog("Bob", 7);
        Dog dog3 = new Dog("Daniel", 5);
        dogs[0] = dog1;
        dogs[1] = dog2;
        dogs[2] = dog3;
        Pair<Dog> result = new Pair<>();
        findMinMaxAge(dogs, result);
        




    }
}
