import java.util.Collection;
import java.util.Set;
import java.util.*;

public class TestPunkt {

    //A1
    public static <T> void printUnique(Collection<T> items) {
        Set<T> uniqueEle = new HashSet<T>(items);
        for(T item : uniqueEle) {
            System.out.println(item);
        }
    }

    //B1
    public static <T> void reversPrint(Iterable<T> items) {
        List<T> list = new ArrayList<>();
        for(T item : items) {
            list.add(item);
        }
        Collections.reverse(list);

        for(T item : list) {
            System.out.print(item);
        }
    }

    //C1
    public <T> ArrayList<T> mergeLists(ArrayList<T> list1, ArrayList<T> list2) {
        ArrayList<T> merged = new ArrayList<>();
        merged.addAll(list1);
        merged.addAll(list2);
        return merged;
    }

    //D1
    public static <T> boolean isPalindrome(LinkedList<T> list) {
        for(int i = 0, j = list.size() - 1; i < j; i++, j--) {
            if (list.get(i) != list.get(j)) {
                return false;
            }
        }
        return true;
    }

    //E1
    public static <T> HashSet<T> findUniqueElements(List<T> list) {
        HashSet<T> list1 = new HashSet<>();
        LinkedHashSet<T> list2 = new LinkedHashSet<>();
        for(T item : list) {
            if(!list2.add(item)) {
                list1.add(item);
            }
        }

        list2.removeAll(list1);
        return new HashSet<>(list2);
    }

    //F1
    public static <T> TreeSet<T> findElemenstInRange(TreeSet<T> treeSet, T lowerBound, T upperBound){
        return (TreeSet<T>) treeSet.subSet(lowerBound, true, upperBound, true);
    }

    //K1

    public static <K, V> HashMap<K, V> countValueOccurrences(HashMap<K, V> map) {
        HashMap<K, V> result = new HashMap<>();
        for(K key : map.keySet()) {
            result.put(key, map.get(key));
        }
        return result;
    }

    //L1


     public static void main(String[] args) {
        ArrayList<Integer> list = new ArrayList<>();
        list.add(1);
        list.add(2);
        list.add(3);
        list.add(4);
        list.add(1);
        list.add(2);

        printUnique(list);

        List<String> list1 = List.of("a", "b", "c");
        reversPrint(list1);

        LinkedList<String> list2 = new LinkedList<>(List.of("b", "b", "a"));
        LinkedList<String> list3 = new LinkedList<>(List.of("k", "a", "j", "a", "k"));
        System.out.println();
        System.out.println(isPalindrome(list2));
        System.out.println(isPalindrome(list3));

        List<Integer> list4 = List.of(1, 2, 2, 3, 3);
        System.out.println(findUniqueElements(list4));

        System.out.println("TreeSet: ");
        TreeSet<Integer> treeSet = new TreeSet<>();
        treeSet.add(1);
        treeSet.add(2);
        treeSet.add(3);
        treeSet.add(4);
        treeSet.add(5);

        TreeSet<Integer> treeSet2 = findElemenstInRange(treeSet, 2, 4);
        for(Integer item : treeSet2) {
            System.out.println(item);
        }

        HashMap<Integer, Integer> map = new HashMap<>();
        map.put(1, 1);
        map.put(2, 2);
        System.out.println(countValueOccurrences(map));
    }
}
